import { useCallback, useState } from 'react';
import List from '../components/List';

const Wrapper = () => {

    const [inputValue, setInputValue] = useState('');
    const [tasks, setTasks] = useState([]);
    const [completed, setCompleted] = useState([]);
    const [removedTasks, SetRemovedTasks] = useState(1);

    const onChange = (event) => {
        const value = event.target.value;
        setInputValue(value);
    }

    const addTask = (event) => {
        event.preventDefault();
        if(inputValue !== ""){
            const task = {
                id: tasks.length + completed.length + removedTasks,
                title: inputValue
            }

            setTasks((prev) => [...prev, task]);
            setInputValue("");
        }
    }
    
    const completeTask = useCallback(
        (id) => {
            setTasks((prevTasks) => {
                const taskIndex = prevTasks.findIndex((task) => task.id === id);
                const updatedTask = { ...prevTasks[taskIndex] };
                setCompleted((prevCompleted) => [...prevCompleted, updatedTask]);
                prevTasks.splice(taskIndex, 1);
                return [...prevTasks];
            });
        },[]
    );
    

    const removeTask = useCallback(
        (id) => {
            setTasks((prevState) => prevState.filter((task) => task.id !== id));
            setCompleted((prevState) => prevState.filter((task) => task.id !== id));
            SetRemovedTasks(removedTasks + 1);
        }, []
    )
    return (
        <div className='wrapper'>

            <div className='list'>
                <form className="user-form">
                    <input type="text" onChange={onChange} value={inputValue} />
                    <button onClick={addTask}>Add Task</button>
                </form>
                <List
                    tasks={tasks}
                    removeTask={removeTask}
                    completeTask={completeTask}
                    showCompleteTask={true}
                />
            </div>
            <div className='list'>
                <List
                    tasks={completed}
                    removeTask={removeTask}
                    completeTask={completeTask}
                    showCompleteTask={false}
                />
            </div>
        </div>
    );
}

export default Wrapper;
