import {
  faPencil,
  faSquareCheck,
  faTrash,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const ListItem = ({
  showCompleteButton,
  handleCompleteClick,
  handleDeleteClick,
  handleEditClick,
  id,
  taskName,
  color,
}) => {
  return (
    <div className="list-item" style={{ border: `1px solid ${color}` }}>
      <p> {taskName}</p>
      <div className="list-item-buttons">
        {showCompleteButton && (
          <FontAwesomeIcon
            icon={faSquareCheck}
            onClick={() => handleCompleteClick(id)}
            className="complete-icon"
          />
        )}
        <FontAwesomeIcon
          icon={faTrash}
          onClick={() => handleDeleteClick(id)}
          className="delete-icon"
        />

        <FontAwesomeIcon
          icon={faPencil}
          onClick={() => handleEditClick(taskName, id)}
          className="edit-icon"
        />
      </div>
    </div>
  );
};

export default ListItem;
