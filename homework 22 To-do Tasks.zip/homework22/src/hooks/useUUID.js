import { v4 as uuidv4 } from 'uuid';
import { useState } from 'react';

function useUUID() {
  const [uuid, setUUID] = useState(uuidv4());

  const generateNewUUID = () => {
    setUUID(uuidv4());
  };

  return { uuid, generateNewUUID };
}

export default useUUID;
