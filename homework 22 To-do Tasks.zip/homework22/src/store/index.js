import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { toDoReducer } from "./to-do/toDoReducers";

const rootReducer = combineReducers({
  todo: toDoReducer
});

const store = configureStore({
  reducer: rootReducer
});

export default store;
