import Item from './Item';
import { PureComponent } from 'react';

class List extends PureComponent{

    render() {
        const { tasks, removeTask, completeTask, showCompleteTask } = this.props;

        return (
            <div>
                {tasks.map((item) => (
                    <Item
                        key={item.id}
                        title={item.title}
                        id={item.id}
                        showCompleteButton={showCompleteTask}
                        remove={removeTask}
                        complete={completeTask}
                    />
                ))}
            </div>
        );
    }
}

export default List;
