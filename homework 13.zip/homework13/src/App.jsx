import './App.css';
import Wrapper from './components/Wrapper';


function App() {
  return (
    <div>
      <Wrapper />
    </div>
  );
}

export default App;
