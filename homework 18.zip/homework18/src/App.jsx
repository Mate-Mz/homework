import React, { useEffect, useState } from "react";
import "./App.css";
import ToDoForm from "./Components/ToDoForm";

const API_KEY = "1q2PiwUd6RyXqC4MoC9Dhb6Q1M5qurYU9Gc4pLJgQYeYOr-zxQ";

const App = () => {
  const [toDoList, setToDoList] = useState([]);

  useEffect(() => {
    fetch("/api/v1/tasksToDo", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${API_KEY}`,
      },
    })
      .then((res) => {
        if (!res.ok) throw new Error("Response failed");
        return res.json();
      })
      .then((data) => {
        const mappedTasks = data.items.map((task) => ({
          name: task.toDoTasks,
          isCompleted: task.isCompleted,
          id: task._uuid,
        }));
        setToDoList(mappedTasks);
      })
      .catch((err) => console.log(err));
  }, []);

  const onFormSubmit = (toDoTasks) => {
    fetch("/api/v1/tasksToDo", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${API_KEY}`,
      },
      body: JSON.stringify([{ toDoTasks }]),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Response failed");
        return res.json();
      })
      .then((data) =>
        setToDoList((prev) => [
          {
            name: data.items[0].toDoTasks,
            isCompleted: false,
            id: data.items[0]._uuid,
          },
          ...prev,
        ])
      )
      .catch((err) => console.log(err));
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>ToDo App</h1>
      </header>
      <main className="App-main">
        <ToDoForm onFormSubmit={onFormSubmit} />
        <div className="task-list">
          {toDoList.map((tasksToDo) => (
            <div className="task-item" key={tasksToDo.id}>
              <h3>{tasksToDo.name}</h3>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default App;
