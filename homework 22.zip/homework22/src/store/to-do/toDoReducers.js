const initialState = {
  showEditToDo: true,
  editedToDoId: "",
  toDoInputValue: "",
  toDoList: [],
};

export const toDoReducer = (state = initialState, action) => {
  switch (action.type) {
    case "ADD_TODO":
      return {
        ...state,
        toDoList: [...state.toDoList, action.payload],
      };
    case "REMOVE_TODO":
      const updatedToDoListRemove = state.toDoList.filter(
        (task) => task.id !== action.payload
      );
      return {
        ...state,
        toDoList: updatedToDoListRemove,
      };
    case "COMPLETE_TODO":
      const updatedToDoListComplete = state.toDoList.map((task) => {
        if (task.id === action.payload) {
          return { ...task, completionStatus: true };
        }
        return task;
      });
      return {
        ...state,
        toDoList: updatedToDoListComplete,
      };
    case "EDIT_TODO":
      const updatedToDoListEdit = state.toDoList.map((task) => {
        if (task.id === action.payload.taskId) {
          return { ...task, taskName: action.payload.taskName};
        }
        return task;
      });
      return {
        ...state,
        toDoList: updatedToDoListEdit,
      };
    case "INPUT_TODO":
      return {
        ...state,
        toDoInputValue: action.payload,
      };
    case "TOGGLE_SHOW_TODO":
      if((action.payload === "Submit" && state.showEditToDo === false) || (action.payload === "Edit" && state.showEditToDo === true)){
        return{
          ...state,
          showEditToDo: !state.showEditToDo,
        }
      }
      return {
        ...state,
      };
    case "SET_EDIT_ID":
      return {
        ...state,
        editedToDoId: action.payload,
      };
    default:
      return state;
  }
};
