export const addToDoAction = (payload) => ({
  type: "ADD_TODO",
  payload,
});
export const removeToDoAction = (payload) => ({
  type: "REMOVE_TODO",
  payload,
});
export const completeToDoAction = (payload) => ({
  type: "COMPLETE_TODO",
  payload,
});
export const editToDoAction = (payload) => ({
  type: "EDIT_TODO",
  payload,
});
export const toggleShowEditToDoAction = (payload) => ({
  type: "TOGGLE_SHOW_TODO",
  payload,
});
export const seteditedToDoId = (payload) => ({
  type: "SET_EDIT_ID",
  payload,
});
export const setToDoInputValueAction = (payload) => ({
  type: "INPUT_TODO",
  payload,
});
