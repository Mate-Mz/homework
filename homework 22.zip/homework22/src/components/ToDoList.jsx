import React from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  completeToDoAction,
  removeToDoAction,
  setToDoInputValueAction,
  seteditedToDoId,
  toggleShowEditToDoAction,
} from "../store/to-do/toDoActions";

import ListItem from "./ListItem";

const ToDoList = ({ CompletedTasksList, title }) => {
  const { toDoList } = useSelector((state) => state.todo);
  const dispatch = useDispatch();

  const handleCompleteClick = (taskId) => {
    dispatch(completeToDoAction(taskId));
  };
  const handleDeleteClick = (taskId) => {
    dispatch(removeToDoAction(taskId));
  };
  const handleEditClick = (taskName, id) => {
    dispatch(setToDoInputValueAction(taskName));
    dispatch(seteditedToDoId(id));
    dispatch(toggleShowEditToDoAction("Edit"));
  };

  return (
    <div className={"list"}>
      <h1>{title}</h1>
      {toDoList.map((task) => {
        if (task.completionStatus === CompletedTasksList) {
          return (
            <ListItem
              key={task.id}
              handleCompleteClick={handleCompleteClick}
              handleDeleteClick={handleDeleteClick}
              handleEditClick={handleEditClick}
              id={task.id}
              showCompleteButton={!CompletedTasksList}
              taskName={task.taskName}
              color= {task.color}
            />
          );
        }
        return null;
      })}
    </div>
  );
};

export default ToDoList;
