import { useDispatch, useSelector } from "react-redux";
import {
  addToDoAction,
  editToDoAction,
  setToDoInputValueAction,
  toggleShowEditToDoAction,
} from "../store/to-do/toDoActions";
import useUUID from "../hooks/useUUID";
import { useState } from "react";

const ToDoForm = () => {
  const { uuid, generateNewUUID } = useUUID();
  const { toDoInputValue, showEditToDo, editedToDoId } = useSelector(
    (state) => state.todo
  );
  const [inputValue, setInputValue] = useState("");
  const dispatch = useDispatch();

  const colors = [
    "#FF5733", // Red-Orange
    "#3498DB", // Cerulean Blue
    "#E74C3C", // Alizarin Crimson
    "#27AE60", // Emerald Green
    "#9B59B6", // Amethyst Purple
    "#F39C12", // Sunflower Yellow
    "#1ABC9C", // Robin's Egg Blue
    "#E67E22", // Carrot Orange
    "#2ECC71", // Shamrock Green
    "#E91E63", // Raspberry Pink
    "#34495E", // Gunmetal Gray
    "#FFD700", // Gold
    "#00CED1", // Dark Turquoise
    "#FF69B4", // Hot Pink
    "#8B4513", // Saddle Brown
  ];

  const onSubmit = (e) => {
    e.preventDefault();
    if (inputValue !== "") {
      generateNewUUID();
      dispatch(
        addToDoAction({
          taskName: toDoInputValue,
          completionStatus: false,
          id: uuid,
          color: colors[Math.round(Math.random() * colors.length)],
        })
      )

      setInputValue("");
      dispatch(setToDoInputValueAction(""));
    }else{
      alert("Please fill out the form");
    }
  };
  const onEdit = (e) => {
    e.preventDefault();
    if (inputValue !== "") {
      dispatch(
        editToDoAction({ taskId: editedToDoId, taskName: toDoInputValue })
      );
      dispatch(toggleShowEditToDoAction("Submit"));
      dispatch(setToDoInputValueAction(""));

      setInputValue("");
    }else{
      alert("Please fill out the form");
    }
  };

  return (
    <form>
      <input
        type="text"
        placeholder="Enter New Task"
        value={toDoInputValue}
        onChange={(e) => {
          setInputValue(e.target.value);
          dispatch(setToDoInputValueAction(e.target.value));
        }}
      />
      {showEditToDo ? (
        <button onClick={onSubmit}>Submit</button>
      ) : (
        <button onClick={onEdit}>Edit</button>
      )}
    </form>
  );
};

export default ToDoForm;
