import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Row = ({name, phone}) => {
  return (
    <View style={styles.row}>
      <Text>{name}</Text>
      <Text>{phone}</Text>
    </View>
  )
}

export default Row

const styles = StyleSheet.create({
    row: {
        padding: 20,
        borderWidth: 1,
        margin: 5,
        borderRadius: 10
    }
})