import { FlatList, StyleSheet, Text } from "react-native";
import React, { useState } from "react";
import Row from "./Row";
import { compareNames } from "./Contacts";

const renderItem = ({ item }) => <Row name={item.name} phone={item.phone} />;

const ContactsList = ({ Contacts }) => {
  return <FlatList data={Contacts} renderItem={renderItem} />;
};

export default ContactsList;

const styles = StyleSheet.create({});
