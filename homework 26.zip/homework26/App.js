import { StatusBar } from "expo-status-bar";
import { useState } from "react";
import { Button, SafeAreaView, StyleSheet, TextInput } from "react-native";
import Contacts, { compareNames } from "./components/Contacts";
import ContactsList from "./components/ContactsList";

export default function App() {
  const [showContacts, setShowContacts] = useState(false);
  const [sortedContacts, setSortedContacts] = useState(Contacts);
  const [searchText, setSearchText] = useState("");

  const sort = () => {
    setSortedContacts((prev) => [...prev.sort(compareNames)]);
  };

  const toggleContacts = () => {
    setShowContacts((prev) => !prev);
  };

  const filterContacts = () => {
    const filteredContacts = Contacts.filter((contact) =>
      contact.name.toLowerCase().includes(searchText.toLowerCase())
    );
    setSortedContacts(filteredContacts);
  };

  return (
    <SafeAreaView style={{ marginTop: 50 }}>
      <TextInput
        style={styles.input}
        placeholder="Search..."
        value={searchText}
        onChangeText={(text) => setSearchText(text)}
        onBlur={filterContacts}
      />
      <Button title="Toggle Contacts" onPress={toggleContacts} />
      <Button title="Sort" onPress={sort} />

      {showContacts && <ContactsList Contacts={sortedContacts} />}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },

  input: {
    height: 40,
    borderColor: "gray",
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 8,
  },
});
