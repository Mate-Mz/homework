import { useEffect, useState } from 'react'

const useLocalStorage = (key, fallback) => {
    const [value, setValue] = useState(JSON.parse(localStorage.getItem(key)) ?? fallback);

    useEffect(()=> {
        JSON.stringify(localStorage.setItem(key, value));
    }, [key, value]);

    return [value, setValue];
}

export default useLocalStorage