import React, { useEffect } from 'react'
import useLocalStorage from './hooks/useLocalStorage'
import './App.css';



const App = () => {

    const [darkMode, toggle] = useLocalStorage('DarkMode', true);

    useEffect(()=>{
        if (darkMode) {
            document.body.classList.add('dark-mode');
        }else {
            document.body.classList.remove('dark-mode');
        }
    });
        
    return (
        <div className='wrapper'>
            <button onClick={() => toggle((prevState) => (!prevState))}>Dark Mode Toggle</button>

        </div>
    )
}

export default App