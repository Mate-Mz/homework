import InputForm from "./components/InputForm";
import TodoList from "./components/TodoList";
import "./App.css"

const App = () => {
  return (
    <div className="App">
      <InputForm />
      <div className="listsContainer">
        <TodoList isCompleted={false} />
        <TodoList isCompleted={true} />
      </div>
    </div>
  );
};

export default App;
