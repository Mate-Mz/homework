import React, { useState, useRef } from "react";

const ToDoForm = ({ onFormSubmit, taskName, userName }) => {
  const taskNameRef = useRef();
  const userNameRef = useRef();
  const deadlineHoursRef = useRef();
  const deadlineMinutesRef = useRef();

  const [showDeadline, setShowDeadline] = useState(false);

  const toggleDeadline = () => {
    setShowDeadline(!showDeadline);
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const taskName = taskNameRef.current.value;
    const userName = userNameRef.current.value;
    const deadlineHours = showDeadline ? deadlineHoursRef.current.value : "";
    const deadlineMinutes = showDeadline ? deadlineMinutesRef.current.value : "";

    const deadline = showDeadline
      ? `${deadlineHours}:${deadlineMinutes}`
      : false;

    onFormSubmit(taskName, userName, deadline);
  };

  return (
    <form onSubmit={onSubmit}>
      <input type="text" placeholder="Enter Task" ref={taskNameRef} defaultValue={taskName}/>
      <input type="text" placeholder="User's Name" ref={userNameRef} defaultValue={userName}/>
      <label>
        Show Deadline:
        <input
          type="checkbox"
          checked={showDeadline}
          onChange={toggleDeadline}
        />
      </label>
      {showDeadline && (
        <div>
          <label>Deadline:</label>
          <select ref={deadlineHoursRef}>
            <option value="" disabled>
              Hours
            </option>
            {Array.from({ length: 24 }, (_, i) => (
              <option key={i} value={i.toString().padStart(2, "0")}>
                {i.toString().padStart(2, "0")}
              </option>
            ))}
          </select>

          <select ref={deadlineMinutesRef}>
            <option value="" disabled>
              Minutes
            </option>
            {Array.from({ length: 60 }, (_, i) => (
              <option key={i} value={i.toString().padStart(2, "0")}>
                {i.toString().padStart(2, "0")}
              </option>
            ))}
          </select>
        </div>
      )}
      <button>Submit</button>
    </form>
  );
};

export default ToDoForm;
