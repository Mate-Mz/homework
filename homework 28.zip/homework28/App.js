import React from "react";
import AppNavigator from "./components/AppNavigator";

const App = () => {
  return <AppNavigator/>;
};


export default App;
