import React, { useEffect, useRef, useState } from "react";
import { View, Text, TouchableOpacity, Image } from "react-native";
import { Camera } from "expo-camera";
import * as MediaLibrary from "expo-media-library";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";

const CameraScreen = () => {
  const [hasPermission, setHasPermission] = useState(false);
  const [cameraType, setCameraType] = useState(Camera.Constants.Type.back);
  const [latestImage, setLatestImage] = useState(null);
  const cameraRef = useRef(null);
  const navigation = useNavigation();

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === "granted");

      const mediaLibraryStatus = await MediaLibrary.requestPermissionsAsync();
      if (mediaLibraryStatus.status === "granted") {
        console.log("Media Library permission granted.");

        const { assets } = await MediaLibrary.getAssetsAsync({
          sortBy: MediaLibrary.SortBy.creationTime,
        });
        if (assets.length > 0) {
          const latestImageUri = assets[0].uri;
          setLatestImage(latestImageUri);
        }
      } else {
        console.log("Media Library permission denied.");
      }
    })();
  }, []);

  const handleCapture = async () => {
    if (cameraRef.current) {
      const photo = await cameraRef.current.takePictureAsync();
      await MediaLibrary.createAssetAsync(photo.uri);
    }
  };

  const toggleCameraType = () => {
    setCameraType(
      cameraType === Camera.Constants.Type.back
        ? Camera.Constants.Type.front
        : Camera.Constants.Type.back
    );
  };

  const navigateToGallery = () => {
    navigation.navigate("Gallery");
  };

  return (
    <View style={styles.container}>
      {hasPermission ? (
        <Camera
          style={styles.cameraContainer}
          type={cameraType}
          ref={cameraRef}
        />
      ) : (
        <Text style={styles.noPermissionText}> No access to the camera</Text>
      )}

      <View style={styles.buttonsContainer}>
        <TouchableOpacity
          onPress={navigateToGallery}
          style={styles.galleryButton}
        >
          {latestImage && (
            <Image
              source={{ uri: latestImage }}
              style={styles.galleryButtonImage}
            />
          )}
        </TouchableOpacity>

        <TouchableOpacity onPress={handleCapture} style={styles.captureButton}>
          <View style={styles.captureButtonInner}></View>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={toggleCameraType}
          style={styles.toggleButton}
        >
          <Ionicons name="camera-reverse" size={32} color="gray" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default CameraScreen;

const styles = {
  container: {
    flex: 1,
    backgroundColor: "black",
    paddingTop: 60
  },
  cameraContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonsContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 20,
  },
  galleryButton: {
    backgroundColor: "transparent",
    padding: 10,
    alignItems: "center",
  },
  galleryButtonImage: {
    width: 50,
    height: 50,
    marginBottom: 5,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: "white",
  },
  captureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "white",
    marginHorizontal: 20,
  },
  captureButtonInner: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: "white",
  },
  toggleButton: {
    marginLeft: 20,
  },
  noPermissionText: {
    marginTop: 20,
    color: "white",
  },
};
