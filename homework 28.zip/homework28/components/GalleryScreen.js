import React, { useEffect, useState } from "react";
import { View, Text, FlatList, Image, StyleSheet, Button } from "react-native";
import * as MediaLibrary from "expo-media-library";

const GalleryScreen = () => {
  const [photos, setPhotos] = useState([]);
  const [permissions, setPermissions] = useState(null);

  useEffect(() => {
    (async () => {
      const { status } = await MediaLibrary.requestPermissionsAsync();
      setPermissions(status);

      if (status === "granted") {
        const media = await MediaLibrary.getAssetsAsync({
          mediaType: "photo",
        });
        setPhotos(media.assets);
      }
    })();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Gallery</Text>
      {permissions !== "granted" ? (
        <Text>No access to the gallery</Text>
      ) : (
        <>
          <FlatList
            data={photos}
            keyExtractor={(item) => item.id}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            renderItem={({ item }) => (
              <Image source={{ uri: item.uri }} style={styles.image} />
            )}
          />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  header: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  image: {
    width: 350,
    height: "80%",
    margin: 10,
  },
});

export default GalleryScreen;
