import React from "react";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import Icon from "react-native-vector-icons/FontAwesome";
import { View, Text } from "react-native";

const Tab = createMaterialTopTabNavigator();

const Camera = () => (
  <View>
    <Text>Tab 1 Content</Text>
  </View>
);

const Chats = () => (
  <View>
    <Text>Tab 2 Content</Text>
  </View>
);

const Status = () => (
  <View>
    <Text>Tab 3 Content</Text>
  </View>
);

const Calls = () => (
  <View>
    <Text>Tab 4 Content</Text>
  </View>
);

const MaterialTopTabNavigator = () => (
  <Tab.Navigator
    screenOptions={() => ({
      tabBarLabelStyle: { fontSize: 13, fontWeight: "500" },
      tabBarItemStyle: { width: 100 },
      tabBarStyle: { backgroundColor: "#075E55", paddingTop: 20 },
      tabBarInactiveTintColor: "#80B0AA",
      tabBarActiveTintColor: "#F6F6F6",
      tabBarIndicatorStyle: { backgroundColor: "#F6F6F6" },
    })}
  >
    <Tab.Screen
      name="Camera"
      component={Camera}
      options={{
        tabBarIcon: ({ color, size }) => (
            <Icon name="camera" size={size} color={color} />
        ),
        tabBarLabel: ()=>{},
      }}
    />

    <Tab.Screen name="chats" component={Chats} />
    <Tab.Screen name="Status" component={Status} />
    <Tab.Screen name="Calls" component={Calls} />
  </Tab.Navigator>
);

export default MaterialTopTabNavigator;
