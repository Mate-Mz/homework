import LinkLayouts from "../layouts/linkLayouts";
import AboutPage from "../pages/AboutPage";
import FactsPage from "../pages/FactsPage";
import MainPage from "../pages/MainPage";

const router = [
    {
        element: <LinkLayouts/>,
        path: '/',
        children: [
            {
                element: <MainPage/>,
                index: true
            },
            {
                element: <AboutPage/>,
                path: '/about'
            },
            {
                element: <FactsPage/>,
                path: 'facts/:id'
            }
        ]
    }
]

export default router;