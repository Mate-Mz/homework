const data = [
    { id: 1, fact: "Sherlock Holmes was depicted as using cocaine and morphine as stimulants." },
    { id: 2, fact: "Holmes was known for his incredible powers of observation and deduction." },
    { id: 3, fact: "He was a skilled actor and frequently used disguises to solve cases." },
    { id: 4, fact: "Holmes was an adept violinist, often playing the violin while thinking." },
    { id: 5, fact: "He had eccentric habits and personality traits, such as intense focus followed by lethargy." },
    { id: 6, fact: "During retirement, Holmes took up beekeeping as a hobby." },
    { id: 7, fact: "Holmes had a close and enduring friendship with his companion, Dr. John Watson." },
    { id: 8, fact: "He applied logical analysis and scientific methods to solve crimes." },
    { id: 9, fact: "Despite his intellect, Holmes was sometimes unaware of certain general knowledge." },
    { id: 10, fact: "Holmes was portrayed as averse to forming emotional attachments, particularly with women." },
    { id: 11, fact: "Conan Doyle's depiction of Holmes's drug use was controversial even during his time." },
    { id: 12, fact: "The character of Sherlock Holmes has profoundly influenced detective literature and media." },
    { id: 13, fact: "Sherlock Holmes is the most famous fictional character." }
];

export default data;