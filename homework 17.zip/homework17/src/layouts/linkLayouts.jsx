import React, { useState } from 'react'
import { Link, Outlet } from 'react-router-dom'
import data from '../components/data';

const LinkLayouts = () => {
  const [factId, setFactId] = useState(1);

  const dataLength = data.length

  const nextFact = () => {
    let newFactId = factId + 1;
    if (newFactId > dataLength) {
      newFactId = 1;
    }
    setFactId(newFactId);
  };
  
  return (
    <div>
    <header>
        <nav>
            <ul>
              <li><Link to= { '/' }>Main</Link></li>
              <li><Link to= { '/about' }>About</Link></li>
              <li><Link to={`/facts/${factId}`} onClick={nextFact}>Random Facts</Link></li>
            </ul>
        </nav>
    </header>

        <Outlet/>
    </div>
  )
}

export default LinkLayouts