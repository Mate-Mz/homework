import React from 'react'
import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import router from './components/router'
import './App.css';

const App = () => {
  return (
    <div className='App'>
      <RouterProvider router={createBrowserRouter(router)} />
    </div>
  )
}

export default App
