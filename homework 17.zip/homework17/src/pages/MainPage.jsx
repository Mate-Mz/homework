import React from 'react'
import sherlockImage from '../assets/Sherlock_Holmes_Portrait_Paget.jpg';

const MainPage = () => {
  return (
    <div className='MainPage'>
      <img src={sherlockImage} alt="Sherlock Holmes" />
      <h1>Sherlock Holmes</h1>
    </div>
  )
}

export default MainPage