import { useParams } from 'react-router-dom'
import data from '../components/data';

const FactsPage = () => {

const { id } = useParams();
const factObject = data.find(item => item.id === parseInt(id));

  if (!factObject) {
    return <h1>Fact Not Found</h1>
  }

  return (
    <div className='fact'>
      <h1>Fact #{factObject.id}:</h1>
      <h1>{factObject.fact}</h1>
    </div>
  )
}

export default FactsPage;
