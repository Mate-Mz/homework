import React from 'react';

const AboutPage = () => {
  return (
    <div>
      <h1>About</h1>
      <p>
        Sherlock Holmes is a fictional detective created by British author Sir Arthur Conan Doyle. The character first appeared in the novel "A Study in Scarlet," published in 1887. Holmes is renowned for his brilliant deductive reasoning, keen observation skills, and logical thinking, which he employs to solve complex mysteries and crimes.
        <br /><br />
        Holmes is known for residing at 221B Baker Street in London, where he shares rooms with his close friend and chronicler, Dr. John H. Watson. Watson is often the narrator of the stories, providing the reader with insights into Holmes's methods and personality.
        <br /><br />
        The Sherlock Holmes stories are set in Victorian and Edwardian London, capturing the atmosphere of the era. Holmes's adventures typically involve perplexing cases brought to him by clients, as well as cases that capture his interest through the challenges they pose to his intellect. His approach to solving crimes often involves close observation of physical evidence, deductive reasoning, and sometimes disguises and undercover work.
        <br /><br />
        The Holmes stories have had a significant impact on detective fiction and popular culture. Some of the most famous stories include "The Hound of the Baskervilles," "The Adventures of Sherlock Holmes," "The Sign of Four," and "The Memoirs of Sherlock Holmes." Doyle wrote a total of four novels and 56 short stories featuring the detective.
        <br /><br />
        Sherlock Holmes's character has been adapted into numerous films, television series, stage productions, and other media, making him one of the most recognizable and enduring fictional characters in history. The character's popularity has led to the development of fan communities, literary studies, and various adaptations that continue to be enjoyed by audiences around the world.
      </p>
    </div>
  );
}

export default AboutPage;
