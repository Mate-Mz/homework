import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
} from "react-native";
import InstagramImage from "./assets/instagram.png";
import facebookLogo from "./assets/facebookLogo.png";
import microsoftLogo from "./assets/microsoftLogo.png";
import appStoreLogo from "./assets/appStoreLogo.png";

const LandingPage = () => {
  return (
    <View style={styles.container}>
      <Image source={InstagramImage} style={styles.instagramImage} />

      <TextInput
        style={styles.inputFields}
        placeholder="Phone number, username, or email"
      />
      <TextInput style={styles.inputFields} placeholder="Password" />

      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Log in</Text>
      </TouchableOpacity>

      <View style={styles.rowView}>
        <View style={styles.line}></View>
        <Text style={{ margin: 2, color: "#737373", fontSize: 10 }}>OR</Text>
        <View style={styles.line}></View>
      </View>

      <View style={styles.rowView}>
        <Image
          source={facebookLogo}
          style={{ width: 15, height: 15, marginRight: 5 }}
        />
        <Text style={{ margin: 2, color: "#385185", fontSize: 11 }}>
          Log in With Facebook
        </Text>
      </View>
      <Text
        style={{
          marginTop: 2,
          marginBottom: 25,
          color: "#385185",
          fontSize: 9,
        }}
      >
        Forgot password?
      </Text>
      <View style={styles.rowView}>
        <Text style={{ fontSize: 11 }}>Don't have an account? </Text>
        <Text style={{ margin: 2, color: "#2997F6", fontSize: 11 }}>
          Sign up
        </Text>
      </View>
      <View style={{ margin: 20, alignItems: "center" }}>
        <Text style={{ fontSize: 11 }}>Get the app.</Text>
        <View style={styles.rowView}>
          <View style={styles.platformsBox}>
            <Image
              source={appStoreLogo}
              style={{ width: 15, height: 15, marginRight: 5 }}
            />
            <View>
              <Text style={{ color: "white", fontSize: 10}}>GET IT ON</Text>
              <Text style={{ color: "white" }}>Google Play</Text>
            </View>
          </View>
          <View style={styles.platformsBox}>
            <Image
              source={microsoftLogo}
              style={{ width: 15, height: 15, marginRight: 5 }}
            />
            <View>
              <Text style={{ color: "white", fontSize: 10}}>GET IT ON</Text>
              <Text style={{ color: "white" }}>Google Play</Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#D7D7D7",
  },
  instagramImage: {
    resizeMode: "contain",
    width: 200,
    height: 100,
    marginVertical: 30,
  },
  inputFields: {
    width: 250,
    padding: 5,
    fontSize: 11,
    marginBottom: 5,
    borderWidth: 1,
    borderColor: "#EDEDED",
    borderRadius: 1.3,
    backgroundColor: "#FAFAFA",
  },
  button: {
    width: 250,
    backgroundColor: "#4CB5F9",
    paddingVertical: 5,
    alignItems: "center",
    borderRadius: 5,
    marginTop: 9,
    marginBottom: 5,
  },
  buttonText: {
    color: "#F3FAFE",
    fontSize: 13,
    fontWeight: "bold",
  },

  rowView: {
    margin: 11,
    alignItems: "center",
    flexDirection: "row",
  },
  line: {
    width: 115,
    height: 1,
    backgroundColor: "#EDEDED",
  },
  platformsBox: {
    margin: 5,
    alignItems: "center",
    flexDirection: "row",
    backgroundColor: "black",
    borderRadius: 5,
    width: 120,
    height: 40,
    padding: 10
  },
});

export default LandingPage;
