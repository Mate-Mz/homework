const initialState = {
  showEditToDo: true,
  editedToDoId: "",
  toDoInputValue: "",
  toDoList: [],
};

const savedState = JSON.parse(localStorage.getItem("todoState"));
const initialTodoState = savedState ? savedState : initialState;

export const toDoReducer = (state = initialTodoState, action) => {
  let newState = state;

  switch (action.type) {
    case "ADD_TODO":
      newState = {
        ...state,
        toDoList: [...state.toDoList, action.payload],
      };
      break;
    case "REMOVE_TODO":
      const updatedToDoListRemove = state.toDoList.filter(
        (task) => task.id !== action.payload
      );
      newState = {
        ...state,
        toDoList: updatedToDoListRemove,
      };
      break;
    case "COMPLETE_TODO":
      const updatedToDoListComplete = state.toDoList.map((task) => {
        if (task.id === action.payload) {
          return { ...task, completionStatus: true };
        }
        return task;
      });
      newState = {
        ...state,
        toDoList: updatedToDoListComplete,
      };
      break;
    case "EDIT_TODO":
      const updatedToDoListEdit = state.toDoList.map((task) => {
        if (task.id === action.payload.taskId) {
          return { ...task, taskName: action.payload.taskName };
        }
        return task;
      });
      newState = {
        ...state,
        toDoList: updatedToDoListEdit,
      };
      break;
    case "INPUT_TODO":
      newState = {
        ...state,
        toDoInputValue: action.payload,
      };
      break;
    case "TOGGLE_SHOW_TODO":
      if (
        (action.payload === "Submit" && state.showEditToDo === false) ||
        (action.payload === "Edit" && state.showEditToDo === true)
      ) {
        newState = {
          ...state,
          showEditToDo: !state.showEditToDo,
        };
      }
      break;
    case "SET_EDIT_ID":
      newState = {
        ...state,
        editedToDoId: action.payload,
      };
      break;
    default:
      newState = state;
  }

  localStorage.setItem("todoState", JSON.stringify(newState));
  return newState;
};
