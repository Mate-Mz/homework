import ToDoForm from "./components/ToDoForm";
import ToDoList from "./components/ToDoList";
import "./App.css";

const App = () => {
  return (
    <div className="App">
      <ToDoForm />
      <div className="lists">
        <ToDoList CompletedTasksList={false} title="To-Do Tasks"/>
        <ToDoList CompletedTasksList={true} title="Completed Tasks"/>
      </div>
    </div>
  );
};

export default App;
